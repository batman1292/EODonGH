# VLC-Qt QML Player Example

A simple VLC-Qt powered QML media player

This example is compatible with:
  - CMake
  - Qt5
  - latest VLC-Qt

## Platform specific notes

### Windows

You can install all required libraries with
```
make install
make windows
```

### OS X

Create package using
```
make install
make dmg
```