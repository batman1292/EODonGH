To run VlcDialog.exe:
=====================
1. Copy all VLC-plugins to the "plugins" directory.

2. Copy the content of the VLC "lua" directory to the "lua" directory.

3. Copy libvlc.dll and libvlccore.dll to the directory where
   VlcDialog.exe is stored or any other directory in your path e.g.
   "C:\Windows". VlcDialog is linked with libvlc 2.0.0!

4. Run VlcDialog.exe. Enjoy!