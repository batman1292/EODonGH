inkscape --export-png ../icons/16x16/vlc-qt.png -w 16 vlc-qt.svg
inkscape --export-png ../icons/16x16/vlc-qt@2x.png -w 32 vlc-qt.svg

inkscape --export-png ../icons/24x24/vlc-qt.png -w 24 vlc-qt.svg
inkscape --export-png ../icons/24x24/vlc-qt@2x.png -w 48 vlc-qt.svg

inkscape --export-png ../icons/32x32/vlc-qt.png -w 32 vlc-qt.svg
inkscape --export-png ../icons/32x32/vlc-qt@2x.png -w 64 vlc-qt.svg

inkscape --export-png ../icons/48x48/vlc-qt.png -w 48 vlc-qt.svg
inkscape --export-png ../icons/48x48/vlc-qt@2x.png -w 96 vlc-qt.svg

inkscape --export-png ../icons/64x64/vlc-qt.png -w 64 vlc-qt.svg
inkscape --export-png ../icons/64x64/vlc-qt@2x.png -w 128 vlc-qt.svg

inkscape --export-png ../icons/128x128/vlc-qt.png -w 128 vlc-qt.svg
inkscape --export-png ../icons/128x128/vlc-qt@2x.png -w 256 vlc-qt.svg

inkscape --export-png ../icons/256x256/vlc-qt.png -w 256 vlc-qt.svg
inkscape --export-png ../icons/256x256/vlc-qt@2x.png -w 512 vlc-qt.svg
