inkscape --export-png ../icons/16x16/vlc.png -w 16 vlc.svg
inkscape --export-png ../icons/16x16/vlc@2x.png -w 32 vlc.svg

inkscape --export-png ../icons/24x24/vlc.png -w 24 vlc.svg
inkscape --export-png ../icons/24x24/vlc@2x.png -w 48 vlc.svg

inkscape --export-png ../icons/32x32/vlc.png -w 32 vlc.svg
inkscape --export-png ../icons/32x32/vlc@2x.png -w 64 vlc.svg

inkscape --export-png ../icons/48x48/vlc.png -w 48 vlc.svg
inkscape --export-png ../icons/48x48/vlc@2x.png -w 96 vlc.svg

inkscape --export-png ../icons/64x64/vlc.png -w 64 vlc.svg
inkscape --export-png ../icons/64x64/vlc@2x.png -w 128 vlc.svg

inkscape --export-png ../icons/128x128/vlc.png -w 128 vlc.svg
inkscape --export-png ../icons/128x128/vlc@2x.png -w 256 vlc.svg

inkscape --export-png ../icons/256x256/vlc.png -w 256 vlc.svg
inkscape --export-png ../icons/256x256/vlc@2x.png -w 512 vlc.svg
