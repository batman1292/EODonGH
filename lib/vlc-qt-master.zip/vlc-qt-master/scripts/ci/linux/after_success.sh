#!/bin/bash
set -ev
